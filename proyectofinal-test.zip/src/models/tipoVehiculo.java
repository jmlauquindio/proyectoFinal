package models;

public enum tipoVehiculo {

	AUTOMOVIL, MOTO, CAMION; 
	
}
