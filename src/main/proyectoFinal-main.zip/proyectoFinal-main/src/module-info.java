/**
 * 
 */
/**
 * 
 */
module proyectoFinal {
	requires java.desktop;
	requires org.junit.jupiter.api;
}