package services;

public class VehiculoService {

}
