package models;

public class Tarifa {

}
