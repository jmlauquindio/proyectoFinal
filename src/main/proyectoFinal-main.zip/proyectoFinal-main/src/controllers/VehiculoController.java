package controllers;

public class VehiculoController {

}
